#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
using namespace std;
int ok;
char c[20];
bool afis=1; ///true or false

void ok_t(char cuv[])
{
    int l = 0;
    if(strlen(cuv) == strlen(c) || strlen(cuv) == strlen(c)+1)
    {
        for(int i=0,j=0 ; i<strlen(c) ; i++,j++)
            {
                 if(c[i]==cuv[j])
                {
                    l++;
                }
                else
                {
                    if(cuv[j]=='@')
                        i--;
                }
            }
    }
    if(l==strlen(c))
        ok++;
}

void VerificareCuv(char NET[], int NR_NET, char*** TR_TER, int NR_TR[], int L, int i,char cuv[], int poz)
{
    char cuv1[100];
    if(i==0 && poz==0)
    {
        for(int j=0 ; j<NR_TR[i] ; j++)
        {
            strcpy(cuv1,cuv);
            int ok = 0;
            strcpy(cuv1,TR_TER[i][j]);
            for(int k=0 ; k<strlen(cuv1) ; k++)
            {
                if(cuv1[k]>='A' && cuv1[k]<='Z')
                {
                    ok++;
                    for(int l=0 ; l<NR_NET ; l++)
                        if(cuv1[k] == NET[l])
                        {
                            VerificareCuv(NET ,NR_NET ,TR_TER ,NR_TR ,L ,l , cuv1, k);
                        }
                     break;
                }
            }
            if(strlen(cuv1)<=L && ok==0 || strlen(cuv1)<=L+1 && (strchr(cuv1,'@')!=0 && ok==0))
                {
                    ok_t(cuv1);
                    if(afis!=0)
                    if(strchr(cuv1,'@')!=0)
                    {
                        for(int m=0 ; m<strlen(cuv1) ; m++)
                            if(cuv1[m]!='@')
                                cout<<cuv1[m];
                        cout<<endl;
                        cout<<strlen(cuv1)-1<<endl;
                    }
                    else
                    {
                        cout<<cuv1<<endl;
                        cout<<strlen(cuv1)<<endl;
                    }
                }
        }
    }
    else
    {
        char aux[100];
        strcpy(aux,cuv+poz+1);
        for(int j=0 ; j<NR_TR[i] ; j++)
        {
            strcpy(cuv1,cuv);
            int ok=0;
            {
                strcpy(cuv1+poz,TR_TER[i][j]);
               /// cout<<cuv1;
                strcpy(cuv1+strlen(cuv1),aux);
               /// cout<<aux;
            }
            for(int k=0 ; k<strlen(cuv1) ; k++)
                if(cuv1[k]>='A' && cuv1[k]<='Z')
                {
                    ok++;
                    for(int l=0;l<NR_NET;l++)
                        if(cuv1[k]==NET[l])
                        {
                            ///system("pause");
                            char cuv2[100];
                            strcpy(cuv2,cuv1);
                            if(strlen(cuv1)<=L+2)
                            VerificareCuv(NET ,NR_NET ,TR_TER ,NR_TR ,L ,l , cuv2, k);
                        }
                     break;

                }
            if(strlen(cuv1)<=L && ok==0 || strlen(cuv1)<=L+1 && (strchr(cuv1,'@')!=0 && ok==0))
                {
                    ok_t(cuv1);
                    if(afis != 0)
                    if(strchr(cuv1,'@')!=0)
                    {
                        for(int m=0 ; m<strlen(cuv1) ; m++)
                            if(cuv1[m]!='@')
                                cout<<cuv1[m];
                        cout<<" "<<strlen(cuv1)-1<<endl;                    }
                    else
                    {
                        cout<<cuv1<<" ";
                        cout<<strlen(cuv1)<<endl;
                    }
                }
        }
    }

}

int main()
{
    ifstream fin("date.in");
    fin>>c;
    int nr_neterminali=0, lungime_max=0;
    int *trazitii_net;
    char ***tranzitii_term;
    char *neterminali;
    char cuv[100],cuv_aux[100];
    cout << "*Vom citi gramatica" << endl;
    cout << "Cati neterminali avem" << endl;
    fin>>nr_neterminali;
    neterminali=new char[nr_neterminali];
    trazitii_net=new int[nr_neterminali];
    tranzitii_term=new char**[nr_neterminali];
    cout << "*Vom citii neterminalii unul cate unul," << endl;
    cout << "cu litera mare si vom specifica cate tranzitii pot avea," << endl;
    cout << "dupa care le vom citi" << endl;
    ///citire
    for(int i=0 ; i<nr_neterminali ; i++)
    {
        fin>>neterminali[i];
        fin>>trazitii_net[i];
        tranzitii_term[i]=new char*[trazitii_net[i]];
        for(int j=0 ; j<trazitii_net[i] ; j++)
        {
            tranzitii_term[i][j]=new char[10];
            fin>>tranzitii_term[i][j];
        }
    }

    ///afisare
    lungime_max = strlen(c) ;
    for(int i=0 ; i<nr_neterminali ; i++)
    {
        cout<<neterminali[i];
        cout<<" -> ";
        for(int j=0 ; j<trazitii_net[i] ; j++)
        {
            cout<<tranzitii_term[i][j];
            if(j<trazitii_net[i]-1)
                cout<<" | ";
        }
        cout<<endl;
    }
    VerificareCuv(neterminali,nr_neterminali,tranzitii_term,trazitii_net,lungime_max,0, cuv, 0);
    cout<<endl<<ok<<endl;
    return 0;
}
